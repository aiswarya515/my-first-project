# SecureCodeLens

A comprehensive Django-based security vulnerability scanner for PHP and Python source code with AI-powered analysis and fallback rule-based scanning.

## Features

### Code Security Analysis
- **AI-Powered Analysis**: Uses Google Gemini API for intelligent vulnerability detection
- **Fallback Rule-Based Scanner**: Automatic fallback to predefined security rules when AI service is unavailable
- **Multi-Language Support**: Analyze PHP and Python code
- **Detailed Vulnerability Reports**: Comprehensive findings with severity levels and recommendations

### User Management
- **User Registration**: Secure account creation with validation
- **User Authentication**: Login and session management
- **Profile Management**: Update personal information and email
- **Password Management**: Secure password change functionality
- **Logout**: Safe session termination

### Scan Management
- **Scan History**: View all previous security scans
- **Detailed Results**: Line-by-line vulnerability analysis
- **Scan Deletion**: Remove old scan records
- **Performance Metrics**: Critical, High, and Medium vulnerability counts

### PDF Reports
- **Professional PDF Generation**: Generate detailed PDF reports for each scan
- **Report Download**: Download scan reports for offline review
- **Comprehensive Details**: Includes metadata, vulnerability summary, and findings

### Dashboard
- **Overview Statistics**: Total scans and vulnerability metrics
- **Quick Access**: Start new scans or view results
- **Scan Timeline**: Organized scan history with filtering

## Installation

### Prerequisites
- Python 3.9+
- Django 6.0.1
- Google Gemini API Key

### Setup Instructions

1. **Clone the Repository**
   ```bash
   cd SecureCodeLens
   ```

2. **Create Virtual Environment**
   ```bash
   python -m venv venv
   
   # On Windows
   venv\Scripts\activate
   
   # On macOS/Linux
   source venv/bin/activate
   ```

3. **Install Dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Configure Environment Variables**
   Create a `.env` file in the project root:
   ```
   GEMINI_API_KEY=your_google_gemini_api_key_here
   DEBUG=True
   SECRET_KEY=your_secret_key_here
   ```

5. **Apply Database Migrations**
   ```bash
   python manage.py makemigrations
   python manage.py migrate
   ```

6. **Create Superuser (Admin)**
   ```bash
   python manage.py createsuperuser
   ```

7. **Run Development Server**
   ```bash
   python manage.py runserver
   ```
   
   Access the application at: `http://localhost:8000`

## Usage

### User Registration
1. Visit the application home page
2. Click "Create an account" or go to `/register/`
3. Fill in your details:
   - Username (required)
   - Email (required)
   - First Name (optional)
   - Last Name (optional)
   - Password (required)
4. Click "Create Account"
5. You'll be automatically logged in

### Login
1. Visit `/login/`
2. Enter your username and password
3. Click "Sign In"

### Scanning Code
1. From the dashboard, click "Start New Scan" or go to `/scan/`
2. Select the programming language (PHP or Python)
3. Paste your source code in the text area
4. Click "Run Security Scan"
5. Wait for the analysis to complete

### Viewing Results
- Results display vulnerability details including:
  - Vulnerability name and severity level
  - Line number where the issue was detected
  - Description of the vulnerability
  - Recommendations to fix the issue
- Statistics show counts of Critical, High, and Medium severity issues
- If fallback scanner was used, a notification is displayed

### Downloading PDF Reports
1. Navigate to a scan result page
2. Click "📥 Download PDF Report" button
3. The PDF will download to your computer
4. The report includes:
   - Scan metadata (user, language, date)
   - Vulnerability summary with severity breakdown
   - Detailed findings for each vulnerability
   - Timestamp of report generation

### Managing Your Profile
1. Click "Profile" in the navigation menu
2. **Profile Settings Tab**:
   - Update your email
   - Update first and last names
   - Username cannot be changed
3. **Change Password Tab**:
   - Enter current password
   - Enter new password
   - Confirm new password
4. Click "Save Changes" or "Update Password"

### Dashboard
- View all your previous scans
- See vulnerability statistics
- Access quick statistics:
  - Total Scans
  - Critical Issues
  - High Issues
- Start new scans directly from the dashboard

## Security Features

### AI Service Fallback
- **Graceful Degradation**: If the Gemini API is unavailable, the system automatically switches to the fallback scanner
- **User Notification**: Users are informed when fallback analysis is used
- **Consistent Experience**: Results are presented in the same format regardless of analysis method

### Rule-Based Fallback Scanner
The fallback scanner includes predefined rules for:

**PHP Vulnerabilities:**
- SQL Injection
- Hardcoded Secrets
- Command Injection
- Insecure File Handling
- Cross-Site Scripting (XSS)
- Weak Password Hashing

**Python Vulnerabilities:**
- SQL Injection
- Hardcoded Secrets
- Command Injection
- Insecure Deserialization
- Insecure File Permissions
- Weak Cryptography
- Insecure Random Number Generation

### Data Security
- User passwords are hashed using Django's authentication system
- Session management with CSRF protection
- SQL injection prevention through parameterized queries
- Secure file handling for PDF uploads and downloads

## Project Structure

```
SecureCodeLens/
├── analyzer/                    # Main application
│   ├── migrations/             # Database migrations
│   ├── admin.py                # Django admin configuration
│   ├── ai_engine.py            # AI analysis with fallback logic
│   ├── apps.py                 # App configuration
│   ├── fallback_scanner.py     # Rule-based fallback scanner
│   ├── forms.py                # User registration and profile forms
│   ├── models.py               # Database models
│   ├── pdf_generator.py        # PDF report generation
│   ├── tests.py                # Unit tests
│   ├── urls.py                 # URL routing
│   └── views.py                # View logic
├── SecureCodeLens/             # Project configuration
│   ├── settings.py             # Django settings
│   ├── urls.py                 # Main URL configuration
│   ├── wsgi.py                 # WSGI application
│   └── asgi.py                 # ASGI application
├── Templates/                  # HTML templates
│   ├── base.html               # Base template (if using template inheritance)
│   ├── dashboard.html          # Dashboard page
│   ├── login.html              # Login page
│   ├── register.html           # Registration page
│   ├── profile.html            # Profile management
│   ├── change_password.html    # Password change page
│   ├── scan.html               # Code scanning form
│   └── result.html             # Scan results display
├── manage.py                   # Django management script
├── db.sqlite3                  # SQLite database
├── requirements.txt            # Python dependencies
└── media/                      # Uploaded files (PDF reports)
```

## API Endpoints

### Authentication
- `GET /login/` - Login page
- `POST /login/` - Process login
- `GET /logout/` - Logout and redirect
- `GET/POST /register/` - Registration page

### Dashboard & Scans
- `GET /` - Home page (redirects to dashboard)
- `GET /dashboard/` - User dashboard
- `GET/POST /scan/` - Code scanning interface
- `GET /scan/<id>/result/` - View scan results
- `GET /scan/<id>/download/` - Download PDF report
- `POST /scan/<id>/delete/` - Delete scan record

### Profile
- `GET/POST /profile/` - Profile management
- `GET/POST /profile/change-password/` - Password change

### Admin
- `GET/POST /admin/` - Django admin interface

## Configuration

### Settings File
Key configuration in `SecureCodeLens/settings.py`:

```python
# Media files for PDF storage
MEDIA_URL = 'media/'
MEDIA_ROOT = BASE_DIR / 'media'

# Login URLs
LOGIN_URL = 'login'
LOGIN_REDIRECT_URL = 'dashboard'
LOGOUT_REDIRECT_URL = 'login'

# Gemini API Key
GEMINI_API_KEY = os.getenv('GEMINI_API_KEY')
```

### Environment Variables
Create a `.env` file:
```
GEMINI_API_KEY=your_api_key_here
DEBUG=True
```

## Database Models

### CodeScan
Stores information about each security scan:
- `user` - Foreign key to User
- `language` - Programming language (PHP/Python)
- `code` - Source code scanned
- `vulnerabilities` - JSON array of vulnerabilities found
- `secure_code` - Suggested secure version (from AI)
- `scanned_at` - Timestamp
- `status` - Scan status (pending/completed/failed)
- `vulnerability_summary` - Text summary
- `critical_count`, `high_count`, `medium_count` - Vulnerability counts
- `used_fallback` - Whether fallback scanner was used
- `error_message` - Error details if scan failed

### ScanReport
Stores generated PDF reports:
- `scan` - OneToOne relation to CodeScan
- `pdf_file` - FileField for PDF storage
- `generated_at` - Report generation timestamp
- `file_name` - Original filename

## Testing

Run tests with:
```bash
python manage.py test
```

## Troubleshooting

### Issue: Gemini API Key Error
**Solution**: Ensure `GEMINI_API_KEY` is set in your `.env` file and is valid

### Issue: PDF Generation Fails
**Solution**: Ensure `reportlab` is installed: `pip install reportlab`

### Issue: Migration Errors
**Solution**: Run migrations in order:
```bash
python manage.py migrate analyzer
```

### Issue: Static Files Not Loading
**Solution**: Collect static files:
```bash
python manage.py collectstatic
```

## Production Deployment

For production deployment:

1. **Update Settings**:
   ```python
   DEBUG = False
   ALLOWED_HOSTS = ['yourdomain.com']
   ```

2. **Use Environment Variables**:
   - Store SECRET_KEY, GEMINI_API_KEY, and DEBUG in environment

3. **Database**:
   - Switch from SQLite to PostgreSQL or MySQL

4. **Static/Media Files**:
   - Configure static file serving (AWS S3, Whitenoise, etc.)
   - Configure media file storage

5. **HTTPS**:
   - Enable HTTPS and set `SECURE_SSL_REDIRECT = True`

6. **Logging**:
   - Configure proper logging for production

## Contributing

Contributions are welcome! Please:
1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## License

This project is licensed under the MIT License.

## Support

For issues and questions, please create an issue in the repository.

## Changelog

### Version 1.0.0 (Initial Release)
- User authentication system
- AI-powered code analysis with Gemini API
- Fallback rule-based scanner
- PDF report generation
- User profile management
- Dashboard and scan history
- Support for PHP and Python code

---

**Note**: This application is designed for security analysis and educational purposes. Always conduct thorough security reviews and follow your organization's security policies.
