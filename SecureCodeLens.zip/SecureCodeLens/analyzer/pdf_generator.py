"""
PDF Report Generator for code scan results.
Generates professional PDF reports with vulnerability details and recommendations.
"""

from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import (
    SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, 
    PageBreak, Image as RLImage
)
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from datetime import datetime
import io
from .models import CodeScan


def generate_pdf_report(scan: CodeScan) -> io.BytesIO:
    """
    Generate a PDF report for a code scan.
    
    Args:
        scan: CodeScan instance
    
    Returns:
        BytesIO object containing the PDF
    """
    
    # Create BytesIO buffer
    buffer = io.BytesIO()
    
    # Create PDF document
    doc = SimpleDocTemplate(
        buffer,
        pagesize=letter,
        rightMargin=0.75 * inch,
        leftMargin=0.75 * inch,
        topMargin=0.75 * inch,
        bottomMargin=0.75 * inch,
    )
    
    # Container for the 'Flowable' objects
    elements = []
    
    # Define styles
    styles = getSampleStyleSheet()
    
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=24,
        textColor=colors.HexColor('#1e3a5f'),
        spaceAfter=6,
        alignment=TA_CENTER,
        fontName='Helvetica-Bold'
    )
    
    heading_style = ParagraphStyle(
        'CustomHeading',
        parent=styles['Heading2'],
        fontSize=14,
        textColor=colors.HexColor('#2563eb'),
        spaceAfter=12,
        spaceBefore=12,
        fontName='Helvetica-Bold'
    )
    
    subheading_style = ParagraphStyle(
        'CustomSubHeading',
        parent=styles['Heading3'],
        fontSize=11,
        textColor=colors.HexColor('#374151'),
        spaceAfter=8,
        fontName='Helvetica-Bold'
    )
    
    normal_style = ParagraphStyle(
        'CustomNormal',
        parent=styles['Normal'],
        fontSize=10,
        textColor=colors.HexColor('#1f2937'),
        spaceAfter=6,
        leading=14
    )
    
    # Add title
    elements.append(Paragraph('SecureCodeLens', title_style))
    elements.append(Paragraph('Code Security Scan Report', styles['Heading2']))
    elements.append(Spacer(1, 0.3 * inch))
    
    # Add metadata
    metadata_data = [
        ['User', scan.user.get_full_name() or scan.user.username],
        ['Language', scan.language.upper()],
        ['Scan Date', scan.scanned_at.strftime('%Y-%m-%d %H:%M:%S')],
        ['Analysis Method', 'AI-Powered' if not scan.used_fallback else 'Rule-Based Fallback'],
    ]
    
    metadata_table = Table(metadata_data, colWidths=[1.5 * inch, 4 * inch])
    metadata_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (0, -1), colors.HexColor('#e5e7eb')),
        ('TEXTCOLOR', (0, 0), (-1, -1), colors.HexColor('#1f2937')),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
        ('TOPPADDING', (0, 0), (-1, -1), 8),
        ('LEFTPADDING', (0, 0), (-1, -1), 10),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
    ]))
    
    elements.append(metadata_table)
    elements.append(Spacer(1, 0.3 * inch))
    
    # Add vulnerability summary
    elements.append(Paragraph('Vulnerability Summary', heading_style))
    
    summary_data = [
        ['Severity', 'Count', 'Percentage'],
        ['🔴 Critical', str(scan.critical_count), f"{(scan.critical_count / max(1, scan.critical_count + scan.high_count + scan.medium_count)) * 100:.1f}%"],
        ['🟠 High', str(scan.high_count), f"{(scan.high_count / max(1, scan.critical_count + scan.high_count + scan.medium_count)) * 100:.1f}%"],
        ['🟡 Medium', str(scan.medium_count), f"{(scan.medium_count / max(1, scan.critical_count + scan.high_count + scan.medium_count)) * 100:.1f}%"],
    ]
    
    summary_table = Table(summary_data, colWidths=[1.5 * inch, 1 * inch, 1.5 * inch])
    summary_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#2563eb')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 11),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 10),
        ('TOPPADDING', (0, 0), (-1, 0), 10),
        ('BACKGROUND', (0, 1), (-1, 1), colors.HexColor('#fee2e2')),
        ('BACKGROUND', (0, 2), (-1, 2), colors.HexColor('#fed7aa')),
        ('BACKGROUND', (0, 3), (-1, 3), colors.HexColor('#fef3c7')),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
        ('FONTSIZE', (0, 1), (-1, -1), 10),
        ('LEFTPADDING', (0, 0), (-1, -1), 10),
        ('RIGHTPADDING', (0, 0), (-1, -1), 10),
        ('TOPPADDING', (0, 1), (-1, -1), 8),
        ('BOTTOMPADDING', (0, 1), (-1, -1), 8),
    ]))
    
    elements.append(summary_table)
    elements.append(Spacer(1, 0.3 * inch))
    
    # Add vulnerability details
    import json
    try:
        vulnerabilities = json.loads(scan.vulnerabilities) if scan.vulnerabilities else []
    except (json.JSONDecodeError, TypeError):
        vulnerabilities = []
    
    if vulnerabilities:
        elements.append(Paragraph('Detailed Findings', heading_style))
        
        for idx, vuln in enumerate(vulnerabilities, 1):
            # Vulnerability header
            vuln_header = f"{idx}. {vuln.get('name', 'Unknown')} [{vuln.get('severity', 'Unknown')}]"
            elements.append(Paragraph(vuln_header, subheading_style))
            
            # Vulnerability details
            details = [
                f"<b>Line Number:</b> {vuln.get('line', 'N/A')}",
                f"<b>Severity:</b> {vuln.get('severity', 'N/A')}",
                f"<b>Description:</b> {vuln.get('description', 'N/A')}",
                f"<b>Recommendation:</b> {vuln.get('recommendation', 'N/A')}",
            ]
            
            for detail in details:
                elements.append(Paragraph(detail, normal_style))
            
            elements.append(Spacer(1, 0.15 * inch))
    else:
        elements.append(Paragraph('No vulnerabilities found.', normal_style))
    
    elements.append(Spacer(1, 0.3 * inch))
    
    # Add summary text
    if scan.vulnerability_summary:
        elements.append(Paragraph('Analysis Summary', heading_style))
        summary_text = scan.vulnerability_summary.replace('\n', '<br/>')
        elements.append(Paragraph(summary_text, normal_style))
        elements.append(Spacer(1, 0.3 * inch))
    
    # Add secure code if available
    if scan.secure_code:
        elements.append(Paragraph('Secure Code (AI-Generated)', heading_style))
        secure_code_text = scan.secure_code.replace('\n', '<br/>')
        elements.append(Paragraph(f"<font face='Courier' size='8'>{secure_code_text}</font>", normal_style))
        elements.append(Spacer(1, 0.3 * inch))
    
    # Add footer
    elements.append(Spacer(1, 0.3 * inch))
    footer_text = f"Generated by SecureCodeLens on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    elements.append(Paragraph(footer_text, ParagraphStyle(
        'Footer',
        parent=styles['Normal'],
        fontSize=8,
        textColor=colors.grey,
        alignment=TA_CENTER
    )))
    
    # Build PDF
    doc.build(elements)
    
    # Get the PDF bytes
    buffer.seek(0)
    return buffer
