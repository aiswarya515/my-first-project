from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone


class CodeScan(models.Model):
    """Model for storing code scan results"""
    
    LANGUAGE_CHOICES = (
        ('php', 'PHP'),
        ('python', 'Python'),
    )
    
    STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('completed', 'Completed'),
        ('failed', 'Failed'),
    )
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='scans')
    language = models.CharField(max_length=20, choices=LANGUAGE_CHOICES)
    code = models.TextField()
    vulnerabilities = models.TextField(blank=True, null=True)
    secure_code = models.TextField(blank=True, null=True)
    scanned_at = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='completed')
    
    # New fields for enhanced functionality
    vulnerability_summary = models.TextField(blank=True, null=True, help_text="Summary of found vulnerabilities")
    critical_count = models.IntegerField(default=0)
    high_count = models.IntegerField(default=0)
    medium_count = models.IntegerField(default=0)
    used_fallback = models.BooleanField(default=False, help_text="Whether fallback scanner was used")
    error_message = models.TextField(blank=True, null=True, help_text="Error message if scan failed")
    
    class Meta:
        ordering = ['-scanned_at']
    
    def __str__(self):
        return f"{self.user.username} - {self.language} - {self.scanned_at}"


class ScanReport(models.Model):
    """Model for storing generated PDF reports"""
    
    scan = models.OneToOneField(CodeScan, on_delete=models.CASCADE, related_name='report')
    pdf_file = models.FileField(upload_to='scan_reports/')
    generated_at = models.DateTimeField(auto_now_add=True)
    file_name = models.CharField(max_length=255, blank=True)
    
    class Meta:
        ordering = ['-generated_at']
    
    def __str__(self):
        return f"Report for {self.scan} - {self.generated_at}"
