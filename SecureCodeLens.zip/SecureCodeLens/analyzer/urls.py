from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('register/', views.register, name='register'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('scan/', views.scan_code, name='scan'),
    path('scan/<int:scan_id>/result/', views.scan_result, name='scan_result'),
    path('scan/<int:scan_id>/download/', views.download_report, name='download_report'),
    path('scan/<int:scan_id>/delete/', views.delete_scan, name='delete_scan'),
    path('profile/', views.profile, name='profile'),
    path('profile/change-password/', views.change_password, name='change_password'),
    path('logout/', views.logout_view, name='logout'),
]