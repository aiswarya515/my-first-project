from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.http import FileResponse, HttpResponse
from django.views.decorators.http import require_http_methods
from django.db import transaction
import json
import os
import markdown
from datetime import datetime

from .ai_engine import analyze_code
from .models import CodeScan, ScanReport, User
from .forms import UserRegistrationForm, UserProfileForm, PasswordChangeForm
from .pdf_generator import generate_pdf_report


def home(request):
    """Redirect home to dashboard or login"""
    if request.user.is_authenticated:
        return redirect('dashboard')
    return redirect('login')


def register(request):
    """User registration view"""
    if request.user.is_authenticated:
        return redirect('dashboard')
    
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            # Log the user in after registration
            login(request, user)
            messages.success(request, f'Welcome {user.username}! Your account has been created successfully.')
            return redirect('dashboard')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f'{field}: {error}')
    else:
        form = UserRegistrationForm()
    
    return render(request, 'register.html', {'form': form})


@login_required(login_url='login')
def dashboard(request):
    """User dashboard with scan history"""
    scans = CodeScan.objects.filter(user=request.user).prefetch_related('report')
    
    # Calculate statistics
    total_scans = scans.count()
    critical_vulns = sum(scan.critical_count for scan in scans)
    high_vulns = sum(scan.high_count for scan in scans)
    medium_vulns = sum(scan.medium_count for scan in scans)
    
    context = {
        'scans': scans,
        'total_scans': total_scans,
        'critical_vulns': critical_vulns,
        'high_vulns': high_vulns,
        'medium_vulns': medium_vulns,
    }
    
    return render(request, 'dashboard.html', context)


@login_required(login_url='login')
def scan_code(request):
    """Code scanning view with error handling"""
    if request.method == 'POST':
        code = request.POST.get('code', '').strip()
        language = request.POST.get('language', '').strip()

        if not code or not language:
            messages.error(request, 'Please select a language and enter code.')
            return render(request, 'scan.html')
        
        if language not in ['php', 'python']:
            messages.error(request, 'Unsupported language. Please select PHP or Python.')
            return render(request, 'scan.html')
        
        try:
            # Perform analysis
            result = analyze_code(code, language)
            
            # Save scan to database
            with transaction.atomic():
                scan = CodeScan.objects.create(
                    user=request.user,
                    language=language,
                    code=code,
                    vulnerabilities=json.dumps(result.get('vulnerabilities', [])),
                    secure_code=result.get('secure_code', ''),
                    vulnerability_summary=result.get('summary', ''),
                    used_fallback=result.get('used_fallback', False),
                    error_message=result.get('error_message', ''),
                    status='completed' if result.get('status') == 'success' else 'failed'
                )
                
                # Extract counts from result
                scan.critical_count = len([v for v in result.get('vulnerabilities', []) 
                                          if v.get('severity') == 'Critical'])
                scan.high_count = len([v for v in result.get('vulnerabilities', []) 
                                      if v.get('severity') == 'High'])
                scan.medium_count = len([v for v in result.get('vulnerabilities', []) 
                                        if v.get('severity') == 'Medium'])
                scan.save()
                
                # Generate PDF report
                try:
                    pdf_buffer = generate_pdf_report(scan)
                    
                    # Save PDF file
                    from django.core.files.base import ContentFile
                    filename = f"scan_report_{scan.id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
                    
                    report = ScanReport.objects.create(
                        scan=scan,
                        file_name=filename
                    )
                    report.pdf_file.save(filename, ContentFile(pdf_buffer.getvalue()))
                    
                except Exception as pdf_error:
                    print(f"PDF generation error: {str(pdf_error)}")
                    # Don't fail the scan if PDF generation fails
                    pass
            
            # Show subtle message if fallback was used, otherwise standard success.
            if result.get('used_fallback'):
                messages.info(request, 'AI unavailable — using rule-based scanner for this scan.')
            messages.success(request, 'Scan completed successfully!')
            
            return redirect('scan_result', scan_id=scan.id)
        
        except Exception as e:
            error_msg = str(e)
            print(f"Scan error: {error_msg}")
            messages.error(request, 
                f'An error occurred during scanning: {error_msg}. Please try again.')
            return render(request, 'scan.html', {'error': error_msg})

    return render(request, 'scan.html')


@login_required(login_url='login')
def scan_result(request, scan_id):
    """Display scan result"""
    scan = get_object_or_404(CodeScan, id=scan_id, user=request.user)
    
    # Parse vulnerabilities
    try:
        vulnerabilities = json.loads(scan.vulnerabilities) if scan.vulnerabilities else []
    except (json.JSONDecodeError, TypeError):
        vulnerabilities = []
    
    # Render secure code and summary as markdown
    full_ai_response_md = ""
    if scan.secure_code:
        code = scan.secure_code.strip()
        # Only wrap if it doesn't already contain markdown code blocks
        if '```' not in code:
            code = f"```{scan.language}\n{code}\n```"
        full_ai_response_md = markdown.markdown(code, extensions=['fenced_code', 'codehilite'])
    
    summary_md = ""
    if scan.vulnerability_summary:
        summary_md = markdown.markdown(scan.vulnerability_summary)

    context = {
        'scan': scan,
        'vulnerabilities': vulnerabilities,
        'has_report': hasattr(scan, 'report'),
        'full_ai_response_md': full_ai_response_md,
        'summary_md': summary_md
    }
    
    return render(request, 'result.html', context)


@login_required(login_url='login')
def download_report(request, scan_id):
    """Download PDF report for a scan"""
    scan = get_object_or_404(CodeScan, id=scan_id, user=request.user)
    
    # Check if report exists
    if not hasattr(scan, 'report'):
        messages.error(request, 'Report not available for this scan.')
        return redirect('scan_result', scan_id=scan_id)
    
    try:
        report = scan.report
        if report.pdf_file:
            response = FileResponse(report.pdf_file.open('rb'), content_type='application/pdf')
            response['Content-Disposition'] = f'attachment; filename="{report.file_name}"'
            return response
    except Exception as e:
        print(f"Download error: {str(e)}")
        messages.error(request, f'Error downloading report: {str(e)}')
        return redirect('scan_result', scan_id=scan_id)


@login_required(login_url='login')
def delete_scan(request, scan_id):
    """Delete a scan record"""
    scan = get_object_or_404(CodeScan, id=scan_id, user=request.user)
    
    if request.method == 'POST':
        scan.delete()
        messages.success(request, 'Scan deleted successfully.')
        return redirect('dashboard')
    
    return redirect('scan_result', scan_id=scan_id)


@login_required(login_url='login')
def profile(request):
    """User profile view"""
    if request.method == 'POST':
        form = UserProfileForm(request.POST, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, 'Profile updated successfully!')
            return redirect('profile')
    else:
        form = UserProfileForm(instance=request.user)
    
    context = {'form': form}
    return render(request, 'profile.html', context)


@login_required(login_url='login')
def change_password(request):
    """Change password view"""
    if request.method == 'POST':
        form = PasswordChangeForm(request.POST)
        if form.is_valid():
            user = request.user
            
            # Verify current password
            if not user.check_password(form.cleaned_data['current_password']):
                messages.error(request, 'Current password is incorrect.')
                return render(request, 'change_password.html', {'form': form})
            
            # Set new password
            user.set_password(form.cleaned_data['new_password'])
            user.save()
            
            # Re-authenticate user
            login(request, user)
            messages.success(request, 'Password changed successfully!')
            return redirect('profile')
    else:
        form = PasswordChangeForm()
    
    return render(request, 'change_password.html', {'form': form})


def logout_view(request):
    """Logout view - handles both GET and POST"""
    if request.method in ['GET', 'POST']:
        logout(request)
        messages.success(request, 'You have been logged out successfully.')
        return redirect('login')
    return redirect('login')
