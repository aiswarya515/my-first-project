from django.test import TestCase, Client
from django.contrib.auth.models import User
from django.urls import reverse
from .models import CodeScan, ScanReport
from .fallback_scanner import FallbackScanner
import json


class FallbackScannerTestCase(TestCase):
    """Test cases for the fallback rule-based scanner"""
    
    def test_python_sql_injection_detection(self):
        """Test detection of SQL injection in Python code"""
        python_code = """
import sqlite3
user_input = request.GET['username']
query = "SELECT * FROM users WHERE username = '" + user_input + "'"
cursor.execute(query)
"""
        result = FallbackScanner.scan_code(python_code, 'python')
        
        self.assertEqual(result['status'], 'success')
        self.assertGreater(len(result['vulnerabilities']), 0)
        self.assertTrue(any('SQL Injection' in v['name'] for v in result['vulnerabilities']))
    
    def test_php_sql_injection_detection(self):
        """Test detection of SQL injection in PHP code"""
        php_code = """
$username = $_GET['username'];
$query = "SELECT * FROM users WHERE username = '" . $username . "'";
mysqli_query($connection, $query);
"""
        result = FallbackScanner.scan_code(php_code, 'php')
        
        self.assertEqual(result['status'], 'success')
        self.assertGreater(len(result['vulnerabilities']), 0)
    
    def test_hardcoded_secrets_detection(self):
        """Test detection of hardcoded secrets"""
        python_code = """
api_key = "sk-1234567890abcdefghijk"
password = "admin123456"
token = "ghp_1234567890abcdefghijklmnopqrst"
"""
        result = FallbackScanner.scan_code(python_code, 'python')
        
        self.assertEqual(result['status'], 'success')
        vulns = result['vulnerabilities']
        hardcoded = [v for v in vulns if 'Hardcoded' in v['name']]
        self.assertGreater(len(hardcoded), 0)
    
    def test_command_injection_detection(self):
        """Test detection of command injection"""
        python_code = """
import os
user_input = input("Enter command: ")
os.system(user_input)
"""
        result = FallbackScanner.scan_code(python_code, 'python')
        
        self.assertEqual(result['status'], 'success')
        self.assertTrue(any('Command Injection' in v['name'] for v in result['vulnerabilities']))
    
    def test_unsupported_language(self):
        """Test handling of unsupported languages"""
        result = FallbackScanner.scan_code("some code", 'javascript')
        
        self.assertEqual(result['status'], 'error')
        self.assertIn('Unsupported language', result['message'])
    
    def test_clean_code_no_vulns(self):
        """Test that clean code produces no vulnerabilities"""
        clean_code = """
def add(a, b):
    '''Add two numbers safely'''
    if isinstance(a, int) and isinstance(b, int):
        return a + b
    raise ValueError('Invalid input')
"""
        result = FallbackScanner.scan_code(clean_code, 'python')
        
        self.assertEqual(result['status'], 'success')
        self.assertEqual(len(result['vulnerabilities']), 0)


class UserAuthenticationTestCase(TestCase):
    """Test cases for user authentication"""
    
    def setUp(self):
        self.client = Client()
        self.test_user = User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='testpass123'
        )
    
    def test_user_registration(self):
        """Test user registration"""
        response = self.client.post(reverse('register'), {
            'username': 'newuser',
            'email': 'newuser@example.com',
            'password1': 'securepass123',
            'password2': 'securepass123',
        })
        
        self.assertEqual(User.objects.filter(username='newuser').count(), 1)
    
    def test_user_login(self):
        """Test user login"""
        response = self.client.post(reverse('login'), {
            'username': 'testuser',
            'password': 'testpass123'
        })
        
        self.assertTrue(response.wsgi_request.user.is_authenticated 
                       or response.status_code == 302)
    
    def test_profile_access_requires_login(self):
        """Test that profile page requires authentication"""
        response = self.client.get(reverse('profile'))
        
        self.assertEqual(response.status_code, 302)  # Redirect to login
    
    def test_authenticated_user_can_access_profile(self):
        """Test that authenticated user can access profile"""
        self.client.login(username='testuser', password='testpass123')
        response = self.client.get(reverse('profile'))
        
        self.assertEqual(response.status_code, 200)


class CodeScanTestCase(TestCase):
    """Test cases for code scanning functionality"""
    
    def setUp(self):
        self.client = Client()
        self.test_user = User.objects.create_user(
            username='scanuser',
            email='scan@example.com',
            password='scanpass123'
        )
        self.client.login(username='scanuser', password='scanpass123')
    
    def test_scan_page_requires_login(self):
        """Test that scan page requires authentication"""
        self.client.logout()
        response = self.client.get(reverse('scan'))
        
        self.assertEqual(response.status_code, 302)  # Redirect to login
    
    def test_authenticated_user_can_access_scan_page(self):
        """Test that authenticated user can access scan page"""
        response = self.client.get(reverse('scan'))
        
        self.assertEqual(response.status_code, 200)
    
    def test_scan_creation(self):
        """Test creating a new scan"""
        response = self.client.post(reverse('scan'), {
            'code': 'print("Hello World")',
            'language': 'python'
        }, follow=True)
        
        # Check that scan was created
        self.assertTrue(CodeScan.objects.filter(user=self.test_user).exists())
    
    def test_dashboard_shows_user_scans(self):
        """Test that dashboard displays user's scans"""
        # Create a scan
        scan = CodeScan.objects.create(
            user=self.test_user,
            language='python',
            code='test code',
            vulnerabilities='[]',
            vulnerability_summary='No issues'
        )
        
        response = self.client.get(reverse('dashboard'))
        
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Python')


class CodeScanModelTestCase(TestCase):
    """Test cases for CodeScan model"""
    
    def setUp(self):
        self.user = User.objects.create_user(username='modeltest', password='pass')
    
    def test_scan_creation(self):
        """Test creating a CodeScan instance"""
        scan = CodeScan.objects.create(
            user=self.user,
            language='python',
            code='print("test")',
            vulnerabilities=json.dumps([]),
            vulnerability_summary='Test'
        )
        
        self.assertEqual(scan.language, 'python')
        self.assertEqual(scan.user, self.user)
        self.assertIsNotNone(scan.scanned_at)
    
    def test_scan_defaults(self):
        """Test default values for CodeScan"""
        scan = CodeScan.objects.create(
            user=self.user,
            language='php',
            code='<?php echo "test"; ?>'
        )
        
        self.assertEqual(scan.status, 'completed')
        self.assertEqual(scan.critical_count, 0)
        self.assertEqual(scan.high_count, 0)
        self.assertEqual(scan.used_fallback, False)
    
    def test_scan_ordering(self):
        """Test that scans are ordered by date (newest first)"""
        scan1 = CodeScan.objects.create(
            user=self.user,
            language='python',
            code='code1'
        )
        scan2 = CodeScan.objects.create(
            user=self.user,
            language='python',
            code='code2'
        )
        
        scans = list(CodeScan.objects.all())
        self.assertEqual(scans[0].id, scan2.id)  # Newest first


class ScanReportModelTestCase(TestCase):
    """Test cases for ScanReport model"""
    
    def setUp(self):
        self.user = User.objects.create_user(username='reporttest', password='pass')
        self.scan = CodeScan.objects.create(
            user=self.user,
            language='python',
            code='test'
        )
    
    def test_report_creation(self):
        """Test creating a ScanReport instance"""
        report = ScanReport.objects.create(
            scan=self.scan,
            file_name='test_report.pdf'
        )
        
        self.assertEqual(report.scan, self.scan)
        self.assertEqual(report.file_name, 'test_report.pdf')
        self.assertIsNotNone(report.generated_at)
    
    def test_report_one_to_one_relationship(self):
        """Test that each scan can have only one report"""
        report1 = ScanReport.objects.create(
            scan=self.scan,
            file_name='report1.pdf'
        )
        
        # Trying to create another report for the same scan should fail
        with self.assertRaises(Exception):
            ScanReport.objects.create(
                scan=self.scan,
                file_name='report2.pdf'
            )


class UrlRoutingTestCase(TestCase):
    """Test cases for URL routing"""
    
    def setUp(self):
        self.client = Client()
    
    def test_home_redirects_to_login_for_anonymous(self):
        """Test that home page redirects to login for anonymous users"""
        response = self.client.get(reverse('home'))
        
        self.assertEqual(response.status_code, 302)
    
    def test_login_page_accessible(self):
        """Test that login page is accessible"""
        response = self.client.get(reverse('login'))
        
        self.assertEqual(response.status_code, 200)
    
    def test_register_page_accessible(self):
        """Test that register page is accessible"""
        response = self.client.get(reverse('register'))
        
        self.assertEqual(response.status_code, 200)
