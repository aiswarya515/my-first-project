from google import genai
import logging
import json
import re
from django.conf import settings

logger = logging.getLogger(__name__)

class GeminiService:
    """
    Centralized service for interacting with Google Gemini API using the modern google-genai client.
    Handles code analysis and secure code generation.
    """
    
    # Using stable, widely available models
    AVAILABLE_MODELS = [
        "gemini-2.5-flash-lite",
    ]
    
    @classmethod
    def is_configured(cls):
        """Check if Gemini API is properly configured."""
        key = getattr(settings, 'GEMINI_API_KEY', '').strip()
        if not key:
            return False
            
        # Only block if it's a known generic placeholder.
        if 'YOUR_KEY' in key.upper():
            return False
            
        return True

    @classmethod
    def analyze_code(cls, code, language):
        """
        Analyze code for security vulnerabilities.
        Returns a dictionary with vulnerabilities, summary, and secure_code.
        """
        if not cls.is_configured():
            return None

        prompt = f"""
Analyze the following {language} code for security vulnerabilities.
Focus on:
- SQL Injection (especially unsanitized queries)
- Command Injection (use of os.system, subprocess, shell=True, eval, exec)
- Cross-Site Scripting (XSS) and CSRF
- Hardcoded Secrets (API keys, passwords, tokens)
- Insecure Authentication and Authorization

IMPORTANT: If you find ANY of the issues above, you MUST list them in the "vulnerabilities" array. DO NOT mark the code as secure if it uses dangerous dynamic execution or unsanitized input in queries.

Return your response in the following JSON format:
{{
    "vulnerabilities": [
        {{
            "name": "Vulnerability Name",
            "severity": "Critical/High/Medium/Low",
            "line": <estimated line number>,
            "description": "Description of the issue",
            "recommendation": "How to fix it"
        }}
    ],
    "summary": "The COMPLETE, detailed AI security report. Explain every finding, why it is a risk, and how you will fix it in the code below. Use Markdown for formatting.",
    "secure_code": "A complete, production-ready, and fully secure refactored version of the code. Include comments within the code to explain security improvements."
}}

Code to analyze:
{code}
"""
        raw_text = cls._generate_content(prompt)
        if not raw_text:
            return None

        result = cls._parse_json(raw_text)
        if result and isinstance(result, dict):
            return result
            
        # Fallback if JSON parsing fails but we have output
        return {
            "vulnerabilities": [],
            "summary": raw_text,
            "secure_code": ""
        }

    @classmethod
    def generate_fix(cls, code, language, vulnerabilities):
        """
        Generate a secure version of the code based on detected vulnerabilities.
        """
        if not cls.is_configured():
            return ""

        vuln_summary = []
        for vuln in vulnerabilities:
            vuln_summary.append(
                f"- {vuln.get('name', 'Issue')} ({vuln.get('severity', 'High')}): {vuln.get('description', '')}"
            )
        
        vuln_text = '\n'.join(vuln_summary)
        
        prompt = f"""TASK: Fix the vulnerabilities in the code below and return ONLY the secure version of that code.

Rules:
- Output ONLY the fixed code.
- Wrap the code in triple backticks with the language identifier.
- DO NOT provide any explanation, labels, or comments.
- DO NOT include ANY text before or after the code block.
- STOP immediately after the closing backticks.

Vulnerabilities to fix:
{vuln_text}

Input Code:
```{language}
{code}
```
"""
        result = cls._generate_content(prompt)
        return result if result else ""

    @classmethod
    def _generate_content(cls, prompt):
        """Helper to try multiple Gemini models using the new GenAI client."""
        client = genai.Client(api_key=settings.GEMINI_API_KEY)
        
        for model_name in cls.AVAILABLE_MODELS:
            try:
                logger.info(f"[GeminiService] Requesting {model_name}...")
                response = client.models.generate_content(
                    model=model_name,
                    contents=prompt
                )
                
                if response and response.text:
                    return response.text.strip()
                
            except Exception as e:
                error_msg = str(e)
                if "RESOURCE_EXHAUSTED" in error_msg:
                    logger.error(f"[GeminiService] Quota exceeded for {model_name}")
                    # Return a specific string to signal quota error
                    return "ERROR:QUOTA_EXCEEDED"
                logger.warning(f"[GeminiService] Model {model_name} error: {error_msg}")
                continue
                
        return None

    @classmethod
    def _parse_json(cls, text):
        """Clean and parse JSON from Gemini response."""
        try:
            # Try to find JSON block
            json_match = re.search(r'```json\s*(.*?)\s*```', text, re.DOTALL)
            if json_match:
                content = json_match.group(1)
            else:
                # Try generic backticks
                json_match = re.search(r'```\s*(.*?)\s*```', text, re.DOTALL)
                if json_match:
                    content = json_match.group(1)
                else:
                    content = text
            
            return json.loads(content)
        except Exception as e:
            logger.error(f"[GeminiService] JSON parse error: {str(e)}")
            return None
