"""
SecureCodeLens Advanced Rule-Based Fallback Scanner
Detects security vulnerabilities in Python and PHP code
Includes basic taint-flow detection for SQL Injection
"""

import re
from typing import List, Dict, Any


# ================= Vulnerability Model =================
class Vulnerability:
    def __init__(self, name, severity, line, pattern, description, recommendation):
        self.name = name
        self.severity = severity
        self.line = line
        self.pattern = pattern
        self.description = description
        self.recommendation = recommendation

    def to_dict(self):
        return {
            "name": self.name,
            "severity": self.severity,
            "line": self.line,
            "pattern": self.pattern,
            "description": self.description,
            "recommendation": self.recommendation,
        }


# ================= Scanner =================
class FallbackScanner:

    # ---------- Python Security Patterns ----------
    PYTHON_PATTERNS = {
        "SQL Injection": {
            "patterns": [
                r"\.execute\s*\(\s*f[\"']",
                r"\.format\(",
                r"%\s*\w+",
                r"\.execute\s*\(.*?\+.*?\)",
                r"\.execute\s*\(.*?\.join\(",
            ],
            "severity": "Critical",
            "description": "SQL query is created using user input directly.",
            "recommendation": (
                "Do not join user input inside SQL query string. "
                "Use parameterized queries like cursor.execute('SELECT * FROM users WHERE id=%s', (user_id,)). "
                "This prevents hackers from changing the query."
            ),
        },

        "Command Injection": {
            "patterns": [
                r"os\.system\s*\(",
                r"subprocess\..*shell\s*=\s*True",
                r"eval\s*\(",
                r"exec\s*\(",
            ],
            "severity": "Critical",
            "description": "Code is executing system commands or Python code dynamically.",
            "recommendation": (
                "Never run user input using os.system, eval, exec, or shell=True. "
                "If needed, use safe APIs and validate input carefully. "
                "Dynamic execution can allow hackers to run dangerous commands."
            ),
        },

        "Hardcoded Secrets": {
            "patterns": [
                r"(?i)(api[_-]?key|password|secret|token)\s*=\s*['\"][^'\"]{6,}['\"]",
            ],
            "severity": "Critical",
            "description": "Password or API key is written directly in code.",
            "recommendation": (
                "Do not store passwords or API keys in code. "
                "Save them in environment variables or .env file and read using os.getenv(). "
                "If code is shared, hackers can steal the secret."
            ),
        },

        "Weak Hashing": {
            "patterns": [
                r"hashlib\.md5",
                r"hashlib\.sha1",
            ],
            "severity": "High",
            "description": "Weak password hashing algorithm used.",
            "recommendation": (
                "Do not use MD5 or SHA1 for passwords. "
                "Use bcrypt, Argon2, or scrypt because they are safer and slower to crack."
            ),
        },
    }

    # ---------- PHP Security Patterns ----------
    PHP_PATTERNS = {
        "User Input Assignment": {
            "patterns": [
                r"\$\w+\s*=\s*\$_(GET|POST|REQUEST)",
            ],
            "severity": "Info",
            "description": "User input is stored in a variable.",
            "recommendation": (
                "Always validate and clean user input using filters like filter_input() "
                "or custom validation before using it in database or output."
            ),
        },

        "SQL Query String": {
            "patterns": [
                r"SELECT\s+.*\$\w+",
                r"INSERT\s+.*\$\w+",
                r"UPDATE\s+.*\$\w+",
                r"DELETE\s+.*\$\w+",
                r"SELECT\s+.*?\.\s*\$\w+",
                r"INSERT\s+.*?\.\s*\$\w+",
                r"UPDATE\s+.*?\.\s*\$\w+",
                r"DELETE\s+.*?\.\s*\$\w+",
            ],
            "severity": "High",
            "description": "SQL query is created using PHP variables directly.",
            "recommendation": (
                "Do not write variables inside SQL string. "
                "Use prepared statements with PDO or mysqli_prepare. "
                "This stops SQL injection attacks."
            ),
        },

        "SQL Query Execution": {
            "patterns": [
                r"mysqli_query\s*\(",
                r"mysql_query\s*\(",
                r"PDO->query\s*\(",
            ],
            "severity": "Info",
            "description": "SQL query execution found.",
            "recommendation": (
                "Use prepared statements instead of direct query execution. "
                "Example: $stmt = $conn->prepare('SELECT * FROM users WHERE username=?');"
            ),
        },

        "Command Injection": {
            "patterns": [
                r"exec\s*\(",
                r"shell_exec\s*\(",
                r"system\s*\(",
            ],
            "severity": "Critical",
            "description": "System command is executed in PHP.",
            "recommendation": (
                "Never pass user input to system commands. "
                "If needed, remove these functions or strictly validate input. "
                "Attackers can run dangerous OS commands."
            ),
        },

        "XSS": {
            "patterns": [
                r"echo\s+\$\w+",
                r"print\s+\$\w+",
            ],
            "severity": "High",
            "description": "User input is printed without escaping.",
            "recommendation": (
                "Use htmlspecialchars($variable) before printing. "
                "This prevents attackers from injecting JavaScript code."
            ),
        },

        "Hardcoded Secrets": {
            "patterns": [
                r"\$(password|secret|token|apiKey)\s*=\s*['\"][^'\"]{4,}['\"]",
            ],
            "severity": "Critical",
            "description": "Secret key or password written directly in PHP code.",
            "recommendation": (
                "Do not store secrets in PHP file. "
                "Use .env file or config file outside public folder. "
                "Hackers can see your password if code leaks."
            ),
        },
    }

    # ================= MAIN SCANNER =================
    @staticmethod
    def scan_code(code: str, language: str) -> Dict[str, Any]:
        language = (language or "").lower().strip()
        vulnerabilities: List[Vulnerability] = []

        if language == "python":
            patterns = FallbackScanner.PYTHON_PATTERNS
        elif language == "php":
            patterns = FallbackScanner.PHP_PATTERNS
        else:
            return {
                "status": "error",
                "message": f"Unsupported language: {language}",
                "vulnerabilities": [],
                "summary": "Unsupported language",
                "vulnerability_count": 0,
                "used_fallback": True,
                "used_ai": False,
            }

        lines = code.split("\n")

        # ======== TAINT FLOW DETECTION FOR PHP SQLi ========
        found_user_input = False
        found_sql_query = False
        found_sql_exec = False

        for i, line in enumerate(lines, start=1):
            if re.search(r"\$_(GET|POST|REQUEST)", line):
                found_user_input = True

            if re.search(r"(SELECT|INSERT|UPDATE|DELETE)", line, re.IGNORECASE) and "$" in line:
                found_sql_query = True

            if re.search(r"mysqli_query|mysql_query|PDO->query", line):
                found_sql_exec = True

        if language == "php" and found_user_input and found_sql_query and found_sql_exec:
            vulnerabilities.append(Vulnerability(
                "SQL Injection",
                "Critical",
                0,
                "Taint Flow",
                "User input is directly used in SQL query execution.",
                "Use prepared statements with bind_param or PDO prepared queries to stop SQL injection."
            ))

        # ======== REGEX SCANNING ========
        for vuln_name, vuln_data in patterns.items():
            for pattern in vuln_data["patterns"]:
                for i, line in enumerate(lines, start=1):
                    if re.search(pattern, line, re.IGNORECASE):
                        vulnerabilities.append(Vulnerability(
                            vuln_name,
                            vuln_data["severity"],
                            i,
                            pattern,
                            vuln_data["description"],
                            vuln_data["recommendation"],
                        ))

        # Deduplicate
        unique = {(v.name, v.line): v for v in vulnerabilities}.values()

        return {
            "status": "success",
            "message": "Fallback scan completed.",
            "vulnerabilities": [v.to_dict() for v in unique],
            "summary": FallbackScanner._generate_summary(list(unique)),
            "vulnerability_count": len(unique),
            "used_fallback": True,
            "used_ai": False,
        }

    # ================= SUMMARY =================
    @staticmethod
    def _generate_summary(vulnerabilities: List[Vulnerability]) -> str:
        if not vulnerabilities:
            return "No vulnerabilities found."

        summary = f"Found {len(vulnerabilities)} vulnerabilities:\n"
        for v in vulnerabilities:
            summary += f"- Line {v.line}: {v.name} ({v.severity})\n"

        return summary
