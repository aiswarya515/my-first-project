from django.contrib import admin
from .models import CodeScan, ScanReport


@admin.register(CodeScan)
class CodeScanAdmin(admin.ModelAdmin):
    """Admin interface for CodeScan model"""
    
    list_display = ('id', 'user', 'language', 'scanned_at', 'status', 'critical_count', 'used_fallback')
    list_filter = ('language', 'status', 'used_fallback', 'scanned_at')
    search_fields = ('user__username', 'user__email', 'code')
    readonly_fields = ('scanned_at', 'id')
    
    fieldsets = (
        ('Scan Information', {
            'fields': ('id', 'user', 'language', 'status', 'scanned_at')
        }),
        ('Code', {
            'fields': ('code',),
            'classes': ('collapse',)
        }),
        ('Analysis Results', {
            'fields': ('vulnerabilities', 'vulnerability_summary', 'secure_code'),
            'classes': ('collapse',)
        }),
        ('Vulnerability Counts', {
            'fields': ('critical_count', 'high_count', 'medium_count')
        }),
        ('Fallback Information', {
            'fields': ('used_fallback', 'error_message'),
            'classes': ('collapse',)
        }),
    )
    
    def get_readonly_fields(self, request, obj=None):
        """Make most fields readonly for existing scans"""
        if obj:
            return self.readonly_fields + ('user', 'language', 'code', 'status', 
                                          'vulnerabilities', 'vulnerability_summary', 
                                          'secure_code', 'critical_count', 'high_count', 
                                          'medium_count', 'used_fallback', 'error_message')
        return self.readonly_fields


@admin.register(ScanReport)
class ScanReportAdmin(admin.ModelAdmin):
    """Admin interface for ScanReport model"""
    
    list_display = ('id', 'scan', 'file_name', 'generated_at')
    list_filter = ('generated_at',)
    search_fields = ('file_name', 'scan__user__username')
    readonly_fields = ('generated_at', 'scan')
    
    fieldsets = (
        ('Report Information', {
            'fields': ('scan', 'file_name', 'generated_at')
        }),
        ('PDF File', {
            'fields': ('pdf_file',)
        }),
    )
