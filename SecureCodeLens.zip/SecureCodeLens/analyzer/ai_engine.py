import os
import json
import logging
from django.conf import settings
from .fallback_scanner import FallbackScanner
from .gemini_service import GeminiService

logger = logging.getLogger(__name__)

def analyze_code(code, language):
    """
    Analyze code for security vulnerabilities using a hybrid approach.
    Runs rule-based scanning as a baseline and enriches with AI findings.
    """
    # 1. Always run Rule-Based Scanner first (the baseline)
    fallback_result = FallbackScanner.scan_code(code, language)
    vulnerabilities = []
    summary = "No vulnerabilities found."
    secure_code = ""
    used_ai = False
    used_fallback = True
    error_message = None

    if fallback_result['status'] == 'success':
        vulnerabilities = fallback_result['vulnerabilities']
        summary = fallback_result['summary']
    
    # 2. Enrich with AI Analysis if configured
    if GeminiService.is_configured():
        try:
            logger.info("[AI Engine] Attempting AI enrichment...")
            ai_result = GeminiService.analyze_code(code, language)
            
            if ai_result == "ERROR:QUOTA_EXCEEDED":
                error_message = "Gemini API quota exceeded. Showing static analysis results only."
            elif ai_result:
                used_ai = True
                # Merge vulnerabilities (deduplicate)
                ai_vulns = ai_result.get('vulnerabilities', [])
                
                # Simple deduplication: if type and line match, prefer AI description
                existing_keys = {(v['name'], v['line']) for v in vulnerabilities}
                for av in ai_vulns:
                    key = (av.get('name'), av.get('line'))
                    if key not in existing_keys:
                        vulnerabilities.append(av)
                    else:
                        # Update existing with AI detail if possible
                        for v in vulnerabilities:
                            if (v['name'], v['line']) == key:
                                v['description'] = av.get('description', v['description'])
                                v['recommendation'] = av.get('recommendation', v['recommendation'])

                # Use AI summary and secure code
                summary = ai_result.get('summary', summary)
                secure_code = ai_result.get('secure_code', '')
                
                # If AI provided no secure code, try specific generation
                if vulnerabilities and not secure_code:
                    secure_code = GeminiService.generate_fix(code, language, vulnerabilities)
                    if secure_code == "ERROR:QUOTA_EXCEEDED":
                        secure_code = ""

        except Exception as e:
            logger.error(f"[AI Engine] Gemini enrichment failed: {str(e)}")
            error_message = f"AI enrichment failed: {str(e)}"

    return {
        'status': 'success',
        'vulnerabilities': vulnerabilities,
        'summary': summary,
        'secure_code': secure_code,
        'used_ai': used_ai,
        'used_fallback': True, # We always use it now as baseline
        'error_message': error_message
    }


def _use_fallback_scanner(code, language, error_msg):
    """
    Use rule-based scanner and then try Gemini for a secure code fix if possible.
    """
    try:
        fallback_result = FallbackScanner.scan_code(code, language)
        
        if fallback_result['status'] == 'success':
            vulnerabilities = fallback_result['vulnerabilities']
            secure_code = ''
            
            # Even if we used fallback scanner, we can still try AI for the fix!
            if GeminiService.is_configured():
                logger.info("[AI Engine] Attempting to generate secure refactoring via AI...")
                fix_result = GeminiService.generate_fix(code, language, vulnerabilities)
                if fix_result == "ERROR:QUOTA_EXCEEDED":
                    secure_code = "" # Or a specific message
                else:
                    secure_code = fix_result
            
            return {
                'status': 'success',
                'vulnerabilities': vulnerabilities,
                'summary': fallback_result['summary'],
                'secure_code': secure_code,
                'used_ai': False,
                'used_fallback': True,
                'error_message': None
            }
        else:
            return {
                'status': 'error',
                'vulnerabilities': [],
                'summary': 'Analysis failed.',
                'secure_code': '',
                'used_ai': False,
                'used_fallback': False,
                'error_message': f"Scan failed: {error_msg}"
            }
            
    except Exception as e:
        logger.error(f"[AI Engine] Fallback scanner error: {str(e)}")
        return {
            'status': 'error',
            'vulnerabilities': [],
            'summary': 'Service temporarily unavailable.',
            'secure_code': '',
            'used_ai': False,
            'used_fallback': False,
            'error_message': str(e)
        }
